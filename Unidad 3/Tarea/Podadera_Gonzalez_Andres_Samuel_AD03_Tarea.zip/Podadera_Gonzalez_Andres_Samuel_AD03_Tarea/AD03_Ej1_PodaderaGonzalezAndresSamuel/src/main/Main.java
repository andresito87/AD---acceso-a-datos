package main;

import view.FormularioPrincipal;

/**
 *
 * @author ANDRÉS SAMUEL PODADERA GONZÁLEZ
 */
public class Main {

    /**
     * Método estático que es el punto de inicio de nuestra aplicación
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FormularioPrincipal formularioPrincipal= new FormularioPrincipal();
        formularioPrincipal.setVisible(true);
    }
    
}
