/**
 * Este paquete contiene clases para la resolución del ejercicio 2 para la escritura
 * en archivos binarios de la información introducida a través de una interfaz gráfica en Swing.
 * <p>Incluye la clase principal {@link Ejercicio2}, que permite escribir información
 * en el archivo datosContacto.dat</p>
 *
 * @author Andrés Samuel Podadera González
 * @version 1.0
 */
package ejercicio2;
