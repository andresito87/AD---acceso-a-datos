/**
 * Este paquete contiene clases para la resolución del ejercicio 3 en el que se 
 * realiza la lectura de archivos binarios y se muestran atraves de una interfaz en Swing(tabla).
 * <p>Incluye la clase principal {@link Ejercicio3}, que permite leer información
 * del archivo datosContacto.dat</p>
 *
 * @author Andrés Samuel Podadera González
 * @version 1.0
 */
package ejercicio3;